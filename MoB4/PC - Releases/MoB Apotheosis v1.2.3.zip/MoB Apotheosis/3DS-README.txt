Running the game on 3DS is actually a little complicated, and support is limited in this area. It's more of an experimental thing; functional enough to play, but don't expect it to work too well.

1. Download LovePotion 2.1.2 (later versions may or may not work) from https://github.com/lovebrew/LovePotion/releases

2. Install it to your 3DS system

3. In the same folder as the .3dsx file, create a new folder named "game"

4. Extract the source code from the .exe and put it in that folder

5. If you want to port your save over, move the save.sav file into the same folder as the .3dsx file.

Note: While LovePotion also offers a Nintendo Switch version, I have at present no way of knowing whether the game will function properly on it.