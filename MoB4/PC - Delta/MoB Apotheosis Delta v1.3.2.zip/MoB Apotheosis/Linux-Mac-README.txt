If you're on a platform other than Windows, don't despair! Just install Love2D (from love2d.org) and change the file's extension from .exe to .love

I was lazy and didn't want to have to distribute the file twice, plus apparently the .exe is just a glorified .zip with the Love2D .exe code embedded in it.